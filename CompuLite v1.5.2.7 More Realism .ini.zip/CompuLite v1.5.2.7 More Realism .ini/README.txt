CompuLite v1.5.2.7 - by https://bejoijo.com

CompuLite - More Realism QoL v1.0 -RSF Tomb  https://rsfclangaming.webs.com/lspdfr-mods

CompuLite More Realism QoL is a replacement .ini config file for CompuLite. The noticable changes to 
CompuLite are subtle and can be changed by users easily. This .cfg is for those who want to drag
drop or who dont want to be bothered with editing files.

INSTRUCTIONS:
1 Navigate to your GTA V Main Directory, if you're modding you should already know where this is.

2 Go into the "plugins" folder and go into the "LSPDFR" folder.

3 Find the file titled "CompuLite", Move this file to somewhere SAFE in the event you would like
to revert to original settings.  NOTE: DO NOT MOVE, DELETE, REPLACE OR MODIFY "COMPULITE.DLL".

4 Load into LSPDFR.



REQUIREMENTS: Previous installation of CompuLite v1.5.2.7 or newer.

Improvements/changes in this file. 

v1.0
*No changes made to default keybinds

*No game pause when opening MDT

*Court case waiting time decreased to 36hrs.

*Disabled screen grain transition upon open of MDT

*ALPR Info Autopopulate in MDT Enabled

*Auto-populate ped info in MDT upon ID enabled.

